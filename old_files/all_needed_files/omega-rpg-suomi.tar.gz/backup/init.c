/* omega copyright (c) 1987,1988,1989 by Laurence Raphael Brothers */
/* init.c */

#include "defs.h"

#include "iinit.h"

#include "minit.h"

/* This file contains all the object and monster definitions */
